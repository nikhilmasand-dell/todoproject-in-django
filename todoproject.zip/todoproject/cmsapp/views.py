from django.shortcuts import render, redirect
from .models import TaskModel
from .forms import TaskForm
import requests

def home(request):
	try:
		
		a1="http://api.openweathermap.org/data/2.5/weather?units=metric"
		a2="&q=" + "Mumbai"
		a3="&appid="+"c6e315d09197cec231495138183954bd"
		wa=a1+a2+a3
	
		res=requests.get(wa)
		#print(res)
	
		data=res.json()
		#print(data)
	
		temp=data['main']['temp']
		print("temperature= ",temp)
	
		msg=data['weather'][0]['description']
		return render(request,'home.html',{'msg':msg,'temp':temp})
	except Exception as e:
		return render(request,'home.html',{'msg':'city not found'})


def showtask(request):
	data=TaskModel.objects.filter(user=request.user)
	return render(request, 'showtask.html', {'data':data})

	'''if request.user.is_authenticated:
		data=TaskModel.objects.all()
		return render(request,'showtask.html',{'data':data})
	else:
		return redirect('ulogin')'''
def addtask(request):
	'''if request.user.is_authenticated:
		if request.method=="POST":
			f=TaskForm(request.POST)
			if f.is_valid():
				f.save()
				fm=TaskForm()
				return render(request,'addtask.html',{'fm':fm,'msg':'task added'})
			else:
				return render(request,'addtask.html',{'fm':f,'msg':'check errors'})
		else:
			fm=TaskForm()
			return render(request,'addtask.html',{'fm':fm})
	else:
		return redirect('ulogin')'''
	if request.user.is_authenticated:
		user=request.user
		if request.method=="POST":
			f=TaskForm(request.POST)
			if f.is_valid():
				f.save()
				fm=TaskForm()
				return render(request, 'addtask.html', {'fm':fm, 'msg':'Your task is saved!'})
			else:
				fm=TaskForm()
				return render(request, 'addtask.html', {'fm':f, 'msg':'Error occured.'})
		else:
			fm=TaskForm(initial={'user':request.user})
			return render(request, 'addtask.html', {'fm':fm})
def search(request):
	sa=request.GET.get('search')
	data=TaskModel.objects.filter(TaskName=sa)
	return render(request, 'showtask.html', {'data':data})
def deletetask(request, id):
	if request.user.is_authenticated:
		d=TaskModel.objects.get(id=id)
		d.delete()
		return redirect('showtask')
	else:
		return redirect('ulogin')

