
from django.contrib import admin
from django.urls import path
#from todoapp.views import home
from cmsapp.views import home,addtask,showtask,deletetask,search
from auapp.views import usignup, ulogin, ulogout, ureset
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',home,name='home'),
    path('usignup/',usignup,name='usignup'),
    path('ulogin/',ulogin,name='ulogin'),
    path('ulogout/',ulogout,name='ulogout'),
    path('ureset/',ureset,name='ureset'),
    path('showtask/',showtask,name='showtask'),
    path('addtask/',addtask,name='addtask'),
    path("deletetask/<int:id>",deletetask,name="deletetask"),
    path('search/',search,name='search'),
]
